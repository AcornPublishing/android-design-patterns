package com.example.kyle.notifierexpanded;

public interface Observer {
    String update();
}
