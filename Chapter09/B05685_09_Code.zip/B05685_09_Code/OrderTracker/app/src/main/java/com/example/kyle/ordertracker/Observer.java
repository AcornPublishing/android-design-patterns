package com.example.kyle.ordertracker;

public interface Observer {
    String update();
}
